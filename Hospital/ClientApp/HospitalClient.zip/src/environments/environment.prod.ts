export const environment = {
  production: true,
   api_url:"https://localhost:7002/api"
};
