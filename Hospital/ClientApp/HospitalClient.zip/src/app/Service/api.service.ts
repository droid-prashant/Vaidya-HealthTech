import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Doctor } from "../Model/doctorModel";
import { environment } from "src/environments/environment";
import { Patient } from "../Model/patientModel";

@Injectable(
    {
        providedIn:'root'
    }

)
export class ApiService{
    constructor(private _http:HttpClient){}

    postDoctor(doctorParam: Doctor):Observable<any>{
        return this._http.post("https://localhost:7002/api/Doctor",doctorParam,{responseType:'json'});
    }

    getDoctor():Observable<any>{
        return this._http.get("https://localhost:7002/api/Doctor",{responseType:'json'});
    }

    getDoctorById(id:number):Observable<any>{
        return this._http.get("https://localhost:7002/api/Doctor/"+id,{responseType:'json'});
    }

    updateDoctor(id:number,doctor:Doctor):Observable<any>{
        return this._http.put("https://localhost:7002/api/Doctor/"+id,doctor,{responseType:'json'})
    }

    deleteDoctor(id:number):Observable<any>{
        return this._http.delete("https://localhost:7002/api/Doctor/"+id,{responseType:'json'});
    }

    postPatient(patient:Patient):Observable<any>{
        return this._http.post("https://localhost:7002/api/Patient",patient,{responseType:'json'});
    }

    getPatient():Observable<any>{
        return this._http.get("https://localhost:7002/api/Patient",{responseType:'json'});
    }
}