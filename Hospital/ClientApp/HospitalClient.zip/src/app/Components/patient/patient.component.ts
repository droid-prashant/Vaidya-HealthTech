import { Component, OnInit } from '@angular/core';
import { Doctor } from 'src/app/Model/doctorModel';
import { Patient } from 'src/app/Model/patientModel';
import { ApiService } from 'src/app/Service/api.service';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {
patient:Patient=new Patient();
doctorList:any;
  doctorId: any;
  patientList: any;
  constructor(private _service:ApiService) { }

  ngOnInit(): void {
    this.listPatient();
    this.listDoctor();
  }

  addPatient(){
    this._service.postPatient(this.patient).subscribe(
      res=>{

      },
      err=>{
        console.log(err);
      }
    );
  }

  listPatient(){
    this._service.getPatient().subscribe(
      res=>{
        this.patientList=res;
        console.log(this.patientList);
      },
      err=>{
        console.log(err);
      }
    );
  }

  listDoctor(){
    this._service.getDoctor().subscribe(
      res=>{
        this.doctorList=res;
      },
      err=>{
        console.log(err);
      }
    );
  }
  onDoctorChange(event:any){
    this.doctorId=event.target.value;
    this.patient.DoctorId=this.doctorId;
    
  }
}
