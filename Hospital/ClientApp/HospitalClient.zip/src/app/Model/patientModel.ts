export class Patient{
    FirstName:string='';
    LastName:string='';
    Address:string='';
    Contact:string='';
    Age:number=0;
    DoctorId:number=0;
}