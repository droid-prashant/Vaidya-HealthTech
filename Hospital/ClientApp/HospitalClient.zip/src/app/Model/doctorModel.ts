export class Doctor{
    public FirstName:string="";
    public LastName:string="";
    public Address:string="";
    public PhoneNumber:string="";
    public Specialist:string="";
}